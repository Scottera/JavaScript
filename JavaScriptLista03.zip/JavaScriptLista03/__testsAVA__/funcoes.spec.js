const { calcularArea, somarInt } = require("../funcoes");

test("Calcular a área de um quadrado com um lado de 2m", () => {
    const area = calcularArea(2);
    expect (area).toBe(4);
})

test("Testar a soma de 1 até 3, sendo o resultado 6", () => {
    const soma = somarInt(3);
    expect (soma).toBe(6);
})