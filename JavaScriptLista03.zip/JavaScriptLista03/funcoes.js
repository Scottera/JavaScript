function somarInt (numero){
    
    var num = 0

    for (var i = 1; i <= numero; i++){
        num += i
    };

    return num

}


function calcularArea (lado) {
    return lado * lado;       

}

module.exports = {
    calcularArea,
    somarInt
}