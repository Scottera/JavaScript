//Definir teste

const { dizerOla, somar, dividir } = require("../funcoes");

test("retorna corretamente mensagem de olá", () => {
    const mensagem = dizerOla('Lucas');                  //const (const porque o valor nao muda) (define a constrant/variável) (nome da variável é mensagem e recebe o resultado da função Olá)
    expect (mensagem).toBe("Olá, Lucas!");
});


test("retorna o resultado de x e y", () => {
    const resultado = somar(1,9);
    expect (resultado).toBe(10);
});


test("retorna o resultado de x e y", () => {
    var x = 1
    var y = 9
    
    var resultado = somar(x,y);
    expect (resultado).toBe(10);
});

test("retorna 0 ao tentar dividir por 0", () => {
    const resultadodiv = dividir(4,0);
    expect (resultadodiv).toBe(0);

});

test("retorna 50 ao tentar dividir por 100 por 2", () => {
    const resultadodiv = dividir(100,2);
    expect (resultadodiv).toBe(50);

});
