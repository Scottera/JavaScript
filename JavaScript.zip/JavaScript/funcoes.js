//Criar função da forma mais simples

//function dizerOla (){
//    console.log("Olá, Mundo!")
//}

//function dizerOla (nome){
//    console.log(`Olá, ${nome}!`) // ou
//    console.log("Olá, " + nome + "!")
//}

//function dizerOla (){
//    return "Eaí, Luas, como cê tá aralho"
//}

function somar (x, y) {
    return x + y;
}

function dizerOla (nome) {
    return `Olá, ${nome}!`;
}

function dividir (x, y) {
    if (y == 0) {
        return 0;
    }

    return x / y;
}

//Exportar funções (geralmente sempre no final do arquivo)
module.exports = {
    dizerOla,
    somar,
    dividir
}



