//Chamar função de outro arquivo (desde que já tenha sido exportado)

const funcoes = require('./funcoes')

//funcoes.dizerOla();

//Chamar apenas uma função separada ou mais

//const { dizerOla, somar } = require('./funcoes') // ./ indica o diretório

//dizerOla("Lucas Scotti");

//const mensagem = dizerOla();
//console.log(mensagem)

console.log(funcoes.somar(1,3))
console.log(funcoes.dividir(100,2))
console.log(funcoes.dividir(4,2))